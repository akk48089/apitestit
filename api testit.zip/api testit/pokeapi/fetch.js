let pokemonName ="";

function loadCache(){
    var cache = document.getElementById("cache");
    cache.innerHTML = "";

    for (let index = 0; index < localStorage.length; index++) {
        let name = localStorage.key(index);
        let nameUpper = name.charAt(0).toUpperCase() + name.slice(1);
        
        cache.innerHTML +=
        `<li><a href="#" onclick="requestPokemon('${name}')">${nameUpper}</a></li>`;
    }
}


function displaypokemon(pokemonData)
{
    console.log(pokemonData);
    //näytetään kuva
    let imageurl = pokemonData.sprites.other.dream_world.front_default;
    document.getElementById("artwork").setAttribute("src", imageurl);

    //näytetään perustiedot
    /*
    let firstletter = pokemonData.name.charAT(0);
    let remainingletters = pokemonData.name.substring(1);
    let firstlettercap = firstletter.toUpperCase();
    let namecapitalized = firstlettercap + remainingletters;
    */
    document.getElementById("nimi").innerHTML = pokemonData.name.charAt(0).toUpperCase() + pokemonData.name.slice(1);
    document.getElementById("xp").innerHTML ="base xp: "+ pokemonData.base_experience;
    document.getElementById("weight").innerHTML="Weight: " + pokemonData.weight +" lbs";
    document.getElementById("height").innerHTML="Height: " + pokemonData.height +" ft";

    //näytetään statsit
    //document.getElementById("stats").innerHTML = pokemonData.stats;
    document.getElementById("stats").innerHTML ="";
    document.getElementById("stats").innerHTML += "<h3>stats</h3>";

    for (let index = 0; index < pokemonData.stats.length; index++) {
        var stat = pokemonData.stats[index];
        document.getElementById("stats").innerHTML += `<li>${stat.stat.name}, base value: ${stat.base_stat}, effort: ${stat.effort}</li>`
    }

    document.getElementById("abilities").innerHTML ="";
    document.getElementById("abilities").innerHTML += "<h3>abilities</h3>";

    pokemonData.abilities.forEach(ability => {
        document.getElementById("abilities").innerHTML += `<li>${ability.ability.name}</li>`
    });
    /*
    document.getElementById("moves").innerHTML ="";
    document.getElementById("moves").innerHTML += "<h3>moves</h3>";

    pokemonData.moves.forEach(move => {
        document.getElementById("moves").innerHTML += `<li>${move.move.name}</li>`
    })
    */
    displayMoves(pokemonData);
    loadCache();
}

function storePokemon(pokemon)
{
    console.log("tallennetaan:"+ pokemon);
    window.localStorage.setItem(pokemonName, JSON.stringify(pokemon));
    displaypokemon(pokemon);
}

function requestPokemon(cachedName = "")
{
    if(cachedName !== "")
        pokemonName = cachedName;
    else   
        pokemonName = document.getElementById("name").value;


    var storedPokemon = localStorage.getItem(pokemonName);

    if (storedPokemon !== null)
    {
        console.log("pokemon löytyi localstoragesta ladataan..");
        displaypokemon(JSON.parse(storedPokemon));
    }
    else
    {
        console.log("ei löytynyt! haetaan apista");
        fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`)
        .then(Response => Response.json())
        .then(data => storePokemon(data));
    }
}

let randomPokemonId

fetch(`https://pokeapi.co/api/v2/pokemon`)
then(response => response.json())
.then(data => {
    let allPokemonCount = data.count;
    console.log("pokemoneja yhteensä: "+ allPokemonCount);
    let randomPokemonId = Math.floor(Math.random() * (allPokemonCount -1));
    console.log("arvottu id: "+ randomPokemonId);

    fetch(`https://pokeapi.co/api/v2/pokemon/${randomPokemonId}`)
    .then(response => json)
})