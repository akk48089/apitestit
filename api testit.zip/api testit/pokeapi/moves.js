class game{
    constructor(title){
        this.title = title;
        this.games = [];
    }
}

function displayMoves(pokemonData){
    console.log("näytetään pokemonin liikkeet");

    var moves = pokemonData.moves;
    var games = [];

    for (let i= 0; i < moves.length; i++) {
        const move = moves[i];

        var gamesList = move.version_group_details;

        for (let x = 0; x < gamesList.length; x++) {
            const game = gamesList[x];

            //if(!games.includes(game.version_group.name))
            //    games.push(game.version_group.name);
            
            for (let index = 0; index < games.length; index++) {
                const cachedGame = games[index];
                
                if(cachedGame.title === game.version_group.name)
                {
                    newGame = new Game(game.version_group.name)
                }
            }
        }
        
    }
    console.log(games)
}
