fetch("https://api.chucknorris.io/jokes/random")
    .then(Response => Response.json())
    .then(data => displayFact(data));

function displayFact(factdata) {
    document.getElementById("fact").innerHTML = factdata.value;
    console.log(factdata);
}